#'
#' @useDynLib DietUnmixing
#' @importFrom Rcpp evalCpp
#' @exportPattern "^[[:alpha:]]+"
NULL