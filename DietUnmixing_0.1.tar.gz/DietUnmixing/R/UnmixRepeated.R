#' Reshaping function
#' 
#' @param n number of subjects
#' @param q number of repeated measurements
#' @param r number of markers
#' @param X matrix (nq*r) of observations
#' 
#' @return Returns a 3D array with n rows, r columns, and q slices
"myreshape" = function(n, q, r, X){
  idq       = 1:q
  idr       = 1:r
  Y         = array(0, dim = c(r, q, n))
  for(i in 1:n){
    Y[,,i] = X[, idq]
    idq      = idq + q
  }
  return(Y)
}

#' 
#' Main Function
#' @rdname add
#' @param Y A data frame (nq*(r + 1)) where the first column correspond to the subject ID, with the label 'ID'
#' @param M Matrix (r*p) of marker concentrations in source material (forage species)
#' @param Algorithm Character string either equal to 'GFCLS' or 'BHLUM'
#' @param params List with parameters for the algorithm chosen. For GFCLS is a list with one element named 
#' 'epsilon' which is the tolerance. For BHLUMN is a list with three elements named: 'nIter', 'burn' and 'thin'
#' which correspond to the number of iterations, burn-in samples and thining interval respectively.
#' @param Ginv Inverse of matrix of relationships (n*n)
'UnmixRepeated' = function(Y, M, Algorithm, params, Ginv = NULL){
  if(Algorithm == 'GFCLS'){
    # Parameters for GFCLS #
    epsilon = params$epsilon
    #maxiter = params$maxiter
  } else if (Algorithm == 'BHLUM'){
    # Parameters for Gibss sampler #
    nIter   = params$nIter
    burn    = params$burn
    thin    = params$thin
  }
  # Format data and get parameters #
  p         = ncol(M)
  r         = nrow(M)
  n         = length(unique(Y$ID))
  t         = nrow(Y)
  q         = t/n
  W         = myreshape(n, q, r, t(as.matrix(Y[, -1])))
  ID        = Y[, 1]
  # Running algorithms #
  if(Algorithm == 'GFCLS' & is.null(Ginv)){
    m1        = FCLS_Rep(M, W, epsilon)
    ThetaHat  = cbind(ID, matrix(c(m1$Theta), ncol = p, byrow = T))
    time      = m1$Time
    se        = m1$s.e.
    Out       = list('ThetaHat' = ThetaHat, 'se' = se, 'time' = time)
  } else if(Algorithm == 'BHLUM' & is.null(Ginv)){
    m1        = BHLU_MNI(W, M, nIter, burn, thin)
    keep      = seq(burn, nIter, by = thin)
    ThetaHat  = cbind(ID, t(colMeans(m1$Theta[keep,,])))
    time      = m1$Time
    Draws     = m1$Theta[keep, ,]
    Out       = list('ThetaHat' = ThetaHat, 'time' = time, 'Draws' = Draws)
  } else if(Algorithm == 'GFCLS' & !is.null(Ginv)){
    m1        = FCLS_Rep(M, W, Ginv, epsilon)
    ThetaHat  = cbind(ID, matrix(c(m1$Theta), ncol = p, byrow = T))
    time      = m1$Time
    se        = m1$s.e.
    Out       = list('ThetaHat' = ThetaHat, 'se' = se, 'time' = time)
  } else if(Algorithm == 'BHLUM' & !is.null(Ginv)){
    m1        = BHLU_MNNRM(W, M, Ginv, nIter, burn, thin)
    keep      = seq(burn, nIter, by = thin)
    ThetaHat  = cbind(ID, t(colMeans(m1$Theta[keep,,])))
    time      = m1$Time
    Draws     = m1$Theta[keep, ,]
    Out       = list('ThetaHat' = ThetaHat, 'time' = time, 'Draws' = Draws)
  }
  return(Out)
}

