#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

arma::cube myreshape(arma::mat A, arma::uword n, arma::uword q, arma::uword r){
  arma::cube X         = zeros(r, q, n);
  arma::uvec idq       = regspace<uvec>(0, q - 1);
  for(uword i = 0; i < n; i++){
    X.slice(i) = A.cols(idq);
    idq        = idq + ones<uvec>(q, 1)*q;
  }
  return(X);
}
