#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _DietUnmixing_BHLU_MNI(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_BHLU_MNNRM(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_FCLS(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_FCLS_NRM(SEXP, SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_FCLS_Rep(SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_MVGSimplex(SEXP, SEXP, SEXP);
extern SEXP _DietUnmixing_nnlsCpp(SEXP, SEXP, SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"_DietUnmixing_BHLU_MNI",   (DL_FUNC) &_DietUnmixing_BHLU_MNI,   5},
    {"_DietUnmixing_BHLU_MNNRM", (DL_FUNC) &_DietUnmixing_BHLU_MNNRM, 6},
    {"_DietUnmixing_FCLS",       (DL_FUNC) &_DietUnmixing_FCLS,       5},
    {"_DietUnmixing_FCLS_NRM",   (DL_FUNC) &_DietUnmixing_FCLS_NRM,   4},
    {"_DietUnmixing_FCLS_Rep",   (DL_FUNC) &_DietUnmixing_FCLS_Rep,   3},
    {"_DietUnmixing_MVGSimplex", (DL_FUNC) &_DietUnmixing_MVGSimplex, 3},
    {"_DietUnmixing_nnlsCpp",    (DL_FUNC) &_DietUnmixing_nnlsCpp,    5},
    {NULL, NULL, 0}
};

void R_init_DietUnmixing(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
