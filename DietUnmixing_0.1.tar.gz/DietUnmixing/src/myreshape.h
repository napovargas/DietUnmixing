#ifndef MYRESHAPE_H
#define MYRESHAPE_H

#include <RcppArmadillo.h>

arma::cube myreshape(arma::mat A, arma::uword n, arma::uword q, arma::uword r);

#endif
